# Nexus.AI — Backend

AI-powered clinical decision support API built with FastAPI + Python 3.12.

## Quick Start

### 1. Clone & set up environment
```bash
cp .env.example .env
# Edit .env with your secrets
```

### 2. Generate required keys
```bash
# PHI Encryption Key (AES-256 via Fernet)
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

# JWT Secret Key
openssl rand -hex 32
```

### 3. Run with Docker (recommended)
```bash
docker-compose up --build
```

### 4. Run locally
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### 5. Run database migrations
```bash
alembic upgrade head
```

## API Docs
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Project Structure
```
nexus_ai/
├── app/
│   ├── main.py              # FastAPI app entry point
│   ├── api/routes/
│   │   ├── auth.py          # Auth endpoints
│   │   ├── patients.py      # Patient CRUD
│   │   ├── diagnostics.py   # Diagnostic cases + WebSocket
│   │   └── ai.py            # Clinical AI endpoints
│   ├── core/
│   │   ├── config.py        # App settings
│   │   ├── security.py      # JWT, bcrypt, PHI encryption
│   │   └── dependencies.py  # Auth dependencies, RBAC
│   ├── db/
│   │   └── session.py       # DB connection
│   ├── models/
│   │   └── models.py        # SQLAlchemy models
│   ├── schemas/
│   │   └── schemas.py       # Pydantic request/response schemas
│   └── services/
│       └── ai_service.py    # OpenAI integration
├── tests/
│   └── test_api.py
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── .env.example
```

## Security & HIPAA Notes
- All PHI fields are encrypted at rest using AES-256 (Fernet)
- JWT access tokens expire in 15 minutes
- All PHI access events are written to the `audit_logs` table
- Patient deletion is soft-delete only (HIPAA 6-year retention)
- MFA (TOTP) is supported and enforced per clinician setting
- TLS must be terminated at the load balancer in production

## Running Tests
```bash
pytest tests/ -v
```
