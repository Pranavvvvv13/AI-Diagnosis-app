import pytest
from httpx import AsyncClient, ASGITransport
from app.main import app


@pytest.mark.asyncio
async def test_health_check():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        response = await ac.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


@pytest.mark.asyncio
async def test_register_and_login():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        # Register
        reg = await ac.post("/auth/register", json={
            "email": "test@nexus.ai",
            "password": "SecurePass123!",
            "role": "physician",
        })
        assert reg.status_code == 201

        # Login
        login = await ac.post("/auth/login", json={
            "email": "test@nexus.ai",
            "password": "SecurePass123!",
        })
        assert login.status_code == 200
        assert "access_token" in login.json()


@pytest.mark.asyncio
async def test_unauthenticated_patient_access():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        response = await ac.get("/patients")
    assert response.status_code == 401
