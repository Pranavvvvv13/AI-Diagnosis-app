import uuid
from datetime import date, datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, EmailStr, field_validator


# --- Auth ---

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    license_number: Optional[str] = None
    role: str = "physician"

    @field_validator("password")
    @classmethod
    def password_strength(cls, v):
        if len(v) < 10:
            raise ValueError("Password must be at least 10 characters")
        return v


class LoginRequest(BaseModel):
    email: EmailStr
    password: str
    mfa_code: Optional[str] = None


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(BaseModel):
    refresh_token: str


class ClinicianOut(BaseModel):
    id: uuid.UUID
    email: str
    role: str
    mfa_enabled: bool
    created_at: datetime

    class Config:
        from_attributes = True


# --- Patient ---

class PatientCreate(BaseModel):
    first_name: str
    last_name: str
    date_of_birth: date
    gender: str
    mrn: str


class PatientUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    gender: Optional[str] = None


class PatientOut(BaseModel):
    id: uuid.UUID
    first_name: str
    last_name: str
    date_of_birth: str
    gender: str
    mrn: str
    created_at: datetime

    class Config:
        from_attributes = True


# --- DiagnosticCase ---

class CaseCreate(BaseModel):
    patient_id: uuid.UUID
    symptoms: Dict[str, Any]
    vitals: Optional[Dict[str, Any]] = None


class CaseOut(BaseModel):
    id: uuid.UUID
    patient_id: uuid.UUID
    clinician_id: uuid.UUID
    symptoms: Dict[str, Any]
    vitals: Optional[Dict[str, Any]]
    status: str
    ai_output: Optional[Dict[str, Any]]
    clinician_confirmed: bool
    created_at: datetime

    class Config:
        from_attributes = True


class ConfirmCaseRequest(BaseModel):
    confirmed: bool


# --- AI ---

class AIAnalyzeRequest(BaseModel):
    case_id: uuid.UUID
    additional_notes: Optional[str] = None


class DifferentialRequest(BaseModel):
    symptoms: List[str]
    vitals: Optional[Dict[str, Any]] = None
    patient_age: Optional[int] = None
    patient_gender: Optional[str] = None


class TreatmentPlanRequest(BaseModel):
    diagnosis: str
    patient_age: Optional[int] = None
    allergies: Optional[List[str]] = None
    current_medications: Optional[List[str]] = None


class DrugInteractionRequest(BaseModel):
    medications: List[str]


class AIResponse(BaseModel):
    result: Dict[str, Any]
    confidence: float
    model_used: str
    citations: List[str] = []
    disclaimer: str = "This output is for clinical decision support only. A licensed clinician must review and confirm before any action is taken."
