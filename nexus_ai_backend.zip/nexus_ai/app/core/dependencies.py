from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.core.security import decode_token
from app.db.session import get_db
from app.models.models import Clinician

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


async def get_current_clinician(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> Clinician:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    payload = decode_token(token)
    if not payload or payload.get("type") != "access":
        raise credentials_exception

    clinician_id: str = payload.get("sub")
    if not clinician_id:
        raise credentials_exception

    result = await db.execute(select(Clinician).where(Clinician.id == clinician_id))
    clinician = result.scalar_one_or_none()
    if not clinician:
        raise credentials_exception
    return clinician


def require_role(*roles: str):
    async def role_checker(clinician: Clinician = Depends(get_current_clinician)):
        if clinician.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied. Required roles: {list(roles)}",
            )
        return clinician
    return role_checker
