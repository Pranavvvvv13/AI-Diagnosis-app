import json
from typing import Any, AsyncGenerator, Dict, List, Optional

from openai import AsyncOpenAI

from app.core.config import settings
from app.models.models import DiagnosticCase

client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

SYSTEM_PROMPT = """You are Nexus.AI, a clinical decision support system.
You assist licensed clinicians only. Always:
- Respond in structured JSON.
- Include a 'confidence' score between 0 and 1.
- Include 'citations' as a list of reference strings.
- Never instruct the clinician to act without their own professional judgement.
- Add a 'disclaimer' reminding that clinician confirmation is required.
"""


async def get_differential_diagnoses(
    symptoms: List[str],
    vitals: Optional[Dict] = None,
    patient_age: Optional[int] = None,
    patient_gender: Optional[str] = None,
) -> Dict[str, Any]:
    prompt = f"""Generate a differential diagnosis list in JSON for:
Symptoms: {symptoms}
Vitals: {vitals or 'not provided'}
Patient age: {patient_age or 'unknown'}, Gender: {patient_gender or 'unknown'}

Respond ONLY with JSON: {{"diagnoses": [...], "confidence": 0.0-1.0, "citations": [...], "reasoning": "..."}}"""

    response = await client.chat.completions.create(
        model=settings.AI_MODEL,
        max_tokens=settings.AI_MAX_TOKENS,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return json.loads(response.choices[0].message.content)


async def get_treatment_plan(
    diagnosis: str,
    patient_age: Optional[int] = None,
    allergies: Optional[List[str]] = None,
    current_medications: Optional[List[str]] = None,
) -> Dict[str, Any]:
    prompt = f"""Suggest a treatment plan in JSON for:
Diagnosis: {diagnosis}
Patient age: {patient_age or 'unknown'}
Allergies: {allergies or []}
Current medications: {current_medications or []}

Respond ONLY with JSON: {{"treatment_options": [...], "first_line": "...", "confidence": 0.0-1.0, "citations": [...], "contraindications": [...]}}"""

    response = await client.chat.completions.create(
        model=settings.AI_MODEL,
        max_tokens=settings.AI_MAX_TOKENS,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return json.loads(response.choices[0].message.content)


async def get_drug_interactions(medications: List[str]) -> Dict[str, Any]:
    prompt = f"""Check for drug interactions among: {medications}
Respond ONLY with JSON: {{"interactions": [...], "severity": "none|mild|moderate|severe", "confidence": 0.0-1.0, "citations": [...], "recommendations": "..."}}"""

    response = await client.chat.completions.create(
        model=settings.AI_MODEL,
        max_tokens=settings.AI_MAX_TOKENS,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return json.loads(response.choices[0].message.content)


async def run_ai_analysis(case: DiagnosticCase) -> AsyncGenerator[Dict, None]:
    """Streaming AI analysis for WebSocket endpoint."""
    symptoms = list(case.symptoms.get("list", []))
    prompt = f"""Analyze this diagnostic case and stream your reasoning:
Symptoms: {symptoms}
Vitals: {case.vitals}
Provide step-by-step analysis, then a final JSON summary."""

    stream = await client.chat.completions.create(
        model=settings.AI_MODEL,
        max_tokens=settings.AI_MAX_TOKENS,
        stream=True,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )

    async for chunk in stream:
        delta = chunk.choices[0].delta.content
        if delta:
            yield {"text": delta}
