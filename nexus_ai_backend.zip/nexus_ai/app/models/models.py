import enum
import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Enum, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base


def now_utc():
    return datetime.now(timezone.utc)


# --- Enums ---

class GenderEnum(str, enum.Enum):
    male = "M"
    female = "F"
    other = "Other"
    unknown = "Unknown"


class RoleEnum(str, enum.Enum):
    admin = "admin"
    physician = "physician"
    nurse = "nurse"
    read_only = "read-only"


class CaseStatusEnum(str, enum.Enum):
    pending = "pending"
    processing = "processing"
    complete = "complete"
    failed = "failed"


# --- Clinician (User) ---

class Clinician(Base):
    __tablename__ = "clinicians"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[RoleEnum] = mapped_column(Enum(RoleEnum), default=RoleEnum.physician)
    license_number: Mapped[str] = mapped_column(String(100), nullable=True)
    mfa_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    mfa_secret: Mapped[str] = mapped_column(String(64), nullable=True)
    last_login: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)

    cases: Mapped[list["DiagnosticCase"]] = relationship("DiagnosticCase", back_populates="clinician")


# --- Patient ---

class Patient(Base):
    __tablename__ = "patients"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    # PHI fields — stored encrypted via app-level AES-256
    first_name_enc: Mapped[str] = mapped_column(Text, nullable=False)
    last_name_enc: Mapped[str] = mapped_column(Text, nullable=False)
    dob_enc: Mapped[str] = mapped_column(Text, nullable=False)
    gender: Mapped[GenderEnum] = mapped_column(Enum(GenderEnum), nullable=False)
    mrn: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    deleted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)

    cases: Mapped[list["DiagnosticCase"]] = relationship("DiagnosticCase", back_populates="patient")


# --- DiagnosticCase ---

class DiagnosticCase(Base):
    __tablename__ = "diagnostic_cases"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    patient_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("patients.id"), nullable=False)
    clinician_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("clinicians.id"), nullable=False)
    symptoms: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    vitals: Mapped[dict] = mapped_column(JSONB, nullable=True, default=dict)
    status: Mapped[CaseStatusEnum] = mapped_column(Enum(CaseStatusEnum), default=CaseStatusEnum.pending)
    ai_output: Mapped[dict] = mapped_column(JSONB, nullable=True)
    clinician_confirmed: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    completed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)

    patient: Mapped["Patient"] = relationship("Patient", back_populates="cases")
    clinician: Mapped["Clinician"] = relationship("Clinician", back_populates="cases")


# --- AuditLog ---

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    clinician_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=True)
    action: Mapped[str] = mapped_column(String(128), nullable=False)
    resource: Mapped[str] = mapped_column(String(128), nullable=True)
    resource_id: Mapped[str] = mapped_column(String(64), nullable=True)
    ip_address: Mapped[str] = mapped_column(String(45), nullable=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    metadata: Mapped[dict] = mapped_column(JSONB, nullable=True, default=dict)
