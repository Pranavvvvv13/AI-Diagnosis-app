from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import auth, patients, diagnostics, ai
from app.core.config import settings

app = FastAPI(
    title="Nexus.AI",
    description="AI-powered clinical decision support backend",
    version="0.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(patients.router, prefix="/patients", tags=["Patients"])
app.include_router(diagnostics.router, prefix="/diagnostics", tags=["Diagnostics"])
app.include_router(ai.router, prefix="/ai", tags=["Clinical AI"])


@app.get("/health", tags=["Health"])
def health_check():
    return {"status": "ok", "service": "nexus-ai"}
