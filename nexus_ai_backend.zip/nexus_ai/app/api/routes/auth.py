from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.core.dependencies import get_current_clinician
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
    verify_totp,
)
from app.db.session import get_db
from app.models.models import AuditLog, Clinician
from app.schemas.schemas import (
    ClinicianOut,
    LoginRequest,
    RefreshRequest,
    RegisterRequest,
    TokenResponse,
)

router = APIRouter()


@router.post("/register", response_model=ClinicianOut, status_code=201)
async def register(body: RegisterRequest, db: AsyncSession = Depends(get_db)):
    existing = await db.execute(select(Clinician).where(Clinician.email == body.email))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Email already registered")

    clinician = Clinician(
        email=body.email,
        password_hash=hash_password(body.password),
        role=body.role,
        license_number=body.license_number,
    )
    db.add(clinician)
    await db.flush()
    return clinician


@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest, request: Request, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Clinician).where(Clinician.email == body.email))
    clinician = result.scalar_one_or_none()

    if not clinician or not verify_password(body.password, clinician.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    if clinician.mfa_enabled:
        if not body.mfa_code:
            raise HTTPException(status_code=401, detail="MFA code required")
        if not verify_totp(clinician.mfa_secret, body.mfa_code):
            raise HTTPException(status_code=401, detail="Invalid MFA code")

    clinician.last_login = datetime.now(timezone.utc)

    log = AuditLog(
        clinician_id=clinician.id,
        action="login",
        ip_address=request.client.host if request.client else None,
    )
    db.add(log)

    return TokenResponse(
        access_token=create_access_token(str(clinician.id)),
        refresh_token=create_refresh_token(str(clinician.id)),
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(body: RefreshRequest, db: AsyncSession = Depends(get_db)):
    payload = decode_token(body.refresh_token)
    if not payload or payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    clinician_id = payload.get("sub")
    result = await db.execute(select(Clinician).where(Clinician.id == clinician_id))
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=401, detail="Clinician not found")

    return TokenResponse(
        access_token=create_access_token(clinician_id),
        refresh_token=create_refresh_token(clinician_id),
    )


@router.post("/logout")
async def logout():
    # With stateless JWT, logout is handled client-side.
    # For production, add a token denylist backed by Redis.
    return {"message": "Logged out successfully"}


@router.get("/me", response_model=ClinicianOut)
async def me(clinician: Clinician = Depends(get_current_clinician)):
    return clinician
