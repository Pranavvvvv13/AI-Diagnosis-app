import uuid
from datetime import timezone, datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.core.dependencies import get_current_clinician
from app.core.security import decrypt_phi, encrypt_phi
from app.db.session import get_db
from app.models.models import AuditLog, Clinician, DiagnosticCase, Patient
from app.schemas.schemas import PatientCreate, PatientOut, PatientUpdate

router = APIRouter()


def _decrypt_patient(p: Patient) -> PatientOut:
    return PatientOut(
        id=p.id,
        first_name=decrypt_phi(p.first_name_enc),
        last_name=decrypt_phi(p.last_name_enc),
        date_of_birth=decrypt_phi(p.dob_enc),
        gender=p.gender,
        mrn=p.mrn,
        created_at=p.created_at,
    )


@router.post("", response_model=PatientOut, status_code=201)
async def create_patient(
    body: PatientCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    existing = await db.execute(select(Patient).where(Patient.mrn == body.mrn))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="MRN already exists")

    patient = Patient(
        first_name_enc=encrypt_phi(body.first_name),
        last_name_enc=encrypt_phi(body.last_name),
        dob_enc=encrypt_phi(str(body.date_of_birth)),
        gender=body.gender,
        mrn=body.mrn,
    )
    db.add(patient)
    await db.flush()

    db.add(AuditLog(clinician_id=clinician.id, action="create_patient", resource="Patient",
                    resource_id=str(patient.id), ip_address=request.client.host if request.client else None))
    return _decrypt_patient(patient)


@router.get("/{patient_id}", response_model=PatientOut)
async def get_patient(
    patient_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await db.execute(
        select(Patient).where(Patient.id == patient_id, Patient.deleted_at.is_(None))
    )
    patient = result.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    db.add(AuditLog(clinician_id=clinician.id, action="view_patient", resource="Patient",
                    resource_id=str(patient_id), ip_address=request.client.host if request.client else None))
    return _decrypt_patient(patient)


@router.get("", response_model=list[PatientOut])
async def list_patients(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    offset = (page - 1) * limit
    result = await db.execute(
        select(Patient).where(Patient.deleted_at.is_(None)).offset(offset).limit(limit)
    )
    patients = result.scalars().all()
    return [_decrypt_patient(p) for p in patients]


@router.put("/{patient_id}", response_model=PatientOut)
async def update_patient(
    patient_id: uuid.UUID,
    body: PatientUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await db.execute(
        select(Patient).where(Patient.id == patient_id, Patient.deleted_at.is_(None))
    )
    patient = result.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    if body.first_name:
        patient.first_name_enc = encrypt_phi(body.first_name)
    if body.last_name:
        patient.last_name_enc = encrypt_phi(body.last_name)
    if body.gender:
        patient.gender = body.gender

    db.add(AuditLog(clinician_id=clinician.id, action="update_patient", resource="Patient",
                    resource_id=str(patient_id), ip_address=request.client.host if request.client else None))
    return _decrypt_patient(patient)


@router.delete("/{patient_id}", status_code=204)
async def delete_patient(
    patient_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await db.execute(
        select(Patient).where(Patient.id == patient_id, Patient.deleted_at.is_(None))
    )
    patient = result.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    # Soft delete — HIPAA requires retention for 6 years
    patient.deleted_at = datetime.now(timezone.utc)
    db.add(AuditLog(clinician_id=clinician.id, action="soft_delete_patient", resource="Patient",
                    resource_id=str(patient_id), ip_address=request.client.host if request.client else None))


@router.get("/{patient_id}/history", response_model=list)
async def patient_history(
    patient_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await db.execute(
        select(DiagnosticCase).where(DiagnosticCase.patient_id == patient_id)
    )
    cases = result.scalars().all()
    return [{"id": str(c.id), "status": c.status, "created_at": str(c.created_at)} for c in cases]
