import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, WebSocket, WebSocketDisconnect
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.core.dependencies import get_current_clinician
from app.db.session import get_db, AsyncSessionLocal
from app.models.models import AuditLog, Clinician, DiagnosticCase
from app.schemas.schemas import CaseCreate, CaseOut, ConfirmCaseRequest
from app.services.ai_service import run_ai_analysis

router = APIRouter()


@router.post("/submit", response_model=CaseOut, status_code=201)
async def submit_case(
    body: CaseCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    case = DiagnosticCase(
        patient_id=body.patient_id,
        clinician_id=clinician.id,
        symptoms=body.symptoms,
        vitals=body.vitals or {},
        status="pending",
    )
    db.add(case)
    await db.flush()

    db.add(AuditLog(clinician_id=clinician.id, action="submit_case", resource="DiagnosticCase",
                    resource_id=str(case.id), ip_address=request.client.host if request.client else None))

    # In production, dispatch to Celery:
    # from app.workers.tasks import run_analysis_task
    # run_analysis_task.delay(str(case.id))

    return case


@router.get("/{case_id}/status")
async def case_status(
    case_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await db.execute(select(DiagnosticCase).where(DiagnosticCase.id == case_id))
    case = result.scalar_one_or_none()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    return {"case_id": str(case_id), "status": case.status}


@router.get("/{case_id}/results", response_model=CaseOut)
async def case_results(
    case_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await db.execute(select(DiagnosticCase).where(DiagnosticCase.id == case_id))
    case = result.scalar_one_or_none()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    if case.status != "complete":
        raise HTTPException(status_code=202, detail=f"Case is still {case.status}")

    db.add(AuditLog(clinician_id=clinician.id, action="view_results", resource="DiagnosticCase",
                    resource_id=str(case_id), ip_address=request.client.host if request.client else None))
    return case


@router.post("/{case_id}/confirm")
async def confirm_case(
    case_id: uuid.UUID,
    body: ConfirmCaseRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await db.execute(select(DiagnosticCase).where(DiagnosticCase.id == case_id))
    case = result.scalar_one_or_none()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    case.clinician_confirmed = body.confirmed
    db.add(AuditLog(clinician_id=clinician.id, action="confirm_case", resource="DiagnosticCase",
                    resource_id=str(case_id), ip_address=request.client.host if request.client else None,
                    metadata={"confirmed": body.confirmed}))
    return {"case_id": str(case_id), "confirmed": body.confirmed}


@router.get("/history", response_model=list[CaseOut])
async def case_history(
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await db.execute(
        select(DiagnosticCase).where(DiagnosticCase.clinician_id == clinician.id)
    )
    return result.scalars().all()


@router.websocket("/{case_id}/stream")
async def stream_results(case_id: uuid.UUID, websocket: WebSocket):
    """
    Real-time WebSocket stream for AI diagnostic results.
    Client connects and receives updates as the AI processes the case.
    """
    await websocket.accept()
    try:
        async with AsyncSessionLocal() as db:
            result = await db.execute(select(DiagnosticCase).where(DiagnosticCase.id == case_id))
            case = result.scalar_one_or_none()
            if not case:
                await websocket.send_json({"error": "Case not found"})
                await websocket.close()
                return

            await websocket.send_json({"event": "connected", "case_id": str(case_id), "status": case.status})

            # Stream AI results as they arrive
            async for chunk in run_ai_analysis(case):
                await websocket.send_json({"event": "chunk", "data": chunk})

            await websocket.send_json({"event": "complete", "case_id": str(case_id)})

    except WebSocketDisconnect:
        pass
    except Exception as e:
        await websocket.send_json({"event": "error", "message": str(e)})
        await websocket.close()
