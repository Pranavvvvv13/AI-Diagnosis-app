from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.core.dependencies import get_current_clinician
from app.core.config import settings
from app.db.session import get_db
from app.models.models import AuditLog, Clinician
from app.schemas.schemas import (
    AIAnalyzeRequest,
    AIResponse,
    DifferentialRequest,
    DrugInteractionRequest,
    TreatmentPlanRequest,
)
from app.services.ai_service import (
    get_differential_diagnoses,
    get_drug_interactions,
    get_treatment_plan,
)

router = APIRouter()

DISCLAIMER = (
    "This output is for clinical decision support only. "
    "A licensed clinician must review and confirm before any action is taken."
)


@router.post("/differential", response_model=AIResponse)
async def differential_diagnosis(
    body: DifferentialRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await get_differential_diagnoses(
        symptoms=body.symptoms,
        vitals=body.vitals,
        patient_age=body.patient_age,
        patient_gender=body.patient_gender,
    )
    db.add(AuditLog(clinician_id=clinician.id, action="ai_differential",
                    ip_address=request.client.host if request.client else None))
    return AIResponse(result=result, confidence=result.pop("confidence", 0.0),
                      model_used=settings.AI_MODEL, disclaimer=DISCLAIMER)


@router.post("/treatment-plan", response_model=AIResponse)
async def treatment_plan(
    body: TreatmentPlanRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await get_treatment_plan(
        diagnosis=body.diagnosis,
        patient_age=body.patient_age,
        allergies=body.allergies,
        current_medications=body.current_medications,
    )
    db.add(AuditLog(clinician_id=clinician.id, action="ai_treatment_plan",
                    ip_address=request.client.host if request.client else None))
    return AIResponse(result=result, confidence=result.pop("confidence", 0.0),
                      model_used=settings.AI_MODEL, disclaimer=DISCLAIMER)


@router.post("/drug-interactions", response_model=AIResponse)
async def drug_interactions(
    body: DrugInteractionRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await get_drug_interactions(medications=body.medications)
    db.add(AuditLog(clinician_id=clinician.id, action="ai_drug_interactions",
                    ip_address=request.client.host if request.client else None))
    return AIResponse(result=result, confidence=result.pop("confidence", 0.0),
                      model_used=settings.AI_MODEL, disclaimer=DISCLAIMER)


@router.get("/models")
async def list_models(clinician: Clinician = Depends(get_current_clinician)):
    return {
        "active_model": settings.AI_MODEL,
        "available_models": ["gpt-4o", "gpt-4-turbo"],
        "max_tokens": settings.AI_MAX_TOKENS,
    }


@router.get("/audit-log")
async def ai_audit_log(
    db: AsyncSession = Depends(get_db),
    clinician: Clinician = Depends(get_current_clinician),
):
    result = await db.execute(
        select(AuditLog)
        .where(AuditLog.clinician_id == clinician.id, AuditLog.action.like("ai_%"))
        .order_by(AuditLog.timestamp.desc())
        .limit(100)
    )
    logs = result.scalars().all()
    return [{"action": l.action, "timestamp": str(l.timestamp), "metadata": l.metadata} for l in logs]
